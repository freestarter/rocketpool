<?php
/*
   /app_api/v1/plan.php
 */
#require_once ('db.ctl.php');
require_once ('base.class.php');

	//check_legal();
	
	$base = new base();

		//Config::load('key');
		$contact_address=	isset( $_GET["contact_address"])? $_GET["contact_address"]:'';

		
		$base = new base();
		///$base->gas_price();
		//die();
        $obj = new stdClass();
        $obj->status = 500;
        $obj->data = [];
		if(empty($contact_address)){
			$obj->r='error contact_address';
				echo json_encode($obj,JSON_UNESCAPED_UNICODE);die;
		}
		$result =$base->get_balance($contact_address,18,"");//0xdac17f958d2ee523a2206206994597c13d831ec7
				if($result['code']==0){
					 $obj->status = 200;
					  $obj->data   = ['amount'=>$result['balance']];
					}
		echo json_encode($obj,JSON_UNESCAPED_UNICODE);die;

     
