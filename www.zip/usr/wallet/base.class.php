<?php

/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2019/7/25
 * Time: 20:23
 */

#define('API_DIR', $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR);
#require_once("./fun/CommonUtil.php"); 
#require_once("./fun/include.inc.php");

require_once "./vendor/autoload.php";
require_once "./Lib/Keccak.php";
require_once "./Lib/Tool.php";
		 use xtype\Ethereum\Client as EthereumClient;
		 use xtype\Ethereum\Utils;
		 use kornrunner\Keccak;
		use Lib\Tool;
		 
//Config::load('upload');
class Base
{
    public $network;    //网络请求 main,test
    public $type;       //币种 btc,eth
	private $host;
	private $infura_host;
	private $eth_main_url='http://api-cn.etherscan.com';
    private $eth_test_url='https://api-ropsten.etherscan.io';
	private $infura_ropsten_url	='https://ropsten.infura.io/v3/43e5ac151282462696cae986ebea08a7';
	private $infura_main_url	='https://mainnet.infura.io/v3/43e5ac151282462696cae986ebea08a7';
	
    private $btc_main_url='https://chain.so/api/v2/';
	private $btc_test_url='https://chain.so/api/v2/';
    public function __construct()
    {
		$this->type ='eth';// SGet('type');
		$this->network ='main';//SGet('network');可修改测试环境
        if($this->network!='test' && $this->network!='main'){
			echo 'network不存在';
			die();
		}
        if($this->type == 'btc'){
           echo '暂时未开通BTC';
		   die();
		} 
        elseif ($this->type == 'eth'){
			$this->host= $this->network=='main'? $this->eth_main_url:$this->eth_test_url;
			$this->infura_host= $this->network=='main'? $this->infura_main_url:$this->infura_ropsten_url;
        }
		else {
			echo '不支持BTC,ETH外的类型';
			die();
		}
    }
	
	public function get_eth_status($txid){
		 $client = new EthereumClient([
		     'base_uri' => $this->infura_host,
		     'timeout' => 120,
		 ]);
	
		try {
		   $result=$client->eth_getTransactionReceipt($txid);
		  // var_dump($result);
		  if($result==null){
		  		return -1;
		  }
		   if($result->status=='0x1'){
			   return 1;
		   }
		   else if($result->status=='0x0'){
			   return 0;
		   }
		   else{
			   return -1;
		   }
		   } catch (\Throwable $e) {
				return false;
		}
	}

    public function get_balance($address,$decimals,$contractaddress=''){
        $account=[];
		$balance='';
		$un_balance='';
		
		// $post_url=empty($contractaddress)?
		// $this->host."/api?module=account&action=balance&tag=latest&address=".$address:
		// $this->host."/api?module=account&action=tokenbalance&contractaddress=".$contractaddress."&tag=latest&address=".$address;
		// var_dump(1);
		// 	$result=$this->curl_request($post_url);
		// 	//var_dump($result);
		// 	$json=json_decode($result);
		// 	if(isset($json->status)&&$json->status=="1"){
		// 		$isOk=true;
		// 		$balance=$json->result;
		// 	}
		// 	else{
		// 	  return ['code'=>500,'r'=>$result];
		// 	}
  //        return ['code'=>0,'balance'=>$balance,'un_balance'=>0];
		  $client = new EthereumClient([
			  'base_uri' => $this->infura_host,
			  'timeout' => 30,
		  ]);
		  
		   try{
		   if(empty($contractaddress)){
			    $nv = $client->eth_getBalance($address,'latest');
			    $nv_we = Utils::hexToDec($nv);
			    $balance = Utils::weiToEth($nv_we,$decimals,false);
			   
			 //    $nv = $client->eth_getBalance($address,'pending');
				// $nv_we = Utils::hexToDec($nv);
			 //    $un_balance = Utils::weiToEth($nv_we,$decimals,false);
				
		   }
		   else{
			   $str = "balanceOf(address)";
			   //SHA-3，之前名为Keccak算法，是一个加密杂凑算法。
			   $hash = Keccak::hash($str,256);
			   $hash_sub = mb_substr($hash,0,8,'utf-8');
			   //接收地址
			   $fill_from = Tool::fill0(Utils::remove0x($address));
			   //开始拼接
			   $trans['to'] =$contractaddress;
			   $trans['data']= "0x" . $hash_sub . $fill_from;// 
			   $nv = $client->eth_call($trans,'latest');
			   $nv_we = Utils::hexToDec($nv);
			   //var_dump($nv_we);
			   $balance = Utils::weiToEth($nv_we,$decimals,false);
			   
			   // $nv = $client->eth_call($trans,'pending');
			   // $nv_we = Utils::hexToDec($nv);
			   // //var_dump($nv_we);
			   // $un_balance = Utils::weiToEth($nv_we,$decimals,false);
		   }
		   }
		   catch(Throwable $e){
				return ['code'=>500,'r'=>$e->getMessage()];
		   }
			return ['code'=>0,'balance'=>round($balance,$decimals),'un_balance'=>0];
    }

    //充提列表
    public function get_txlist($address,$side,$decimals,$contractaddress=''){
      	 $post_url=empty($contractaddress)?
         $this->host."/api?module=account&action=txlist&page=1&offset=200&apikey=6CS7J3VWEWVN3N2SXQHX2WHMC5KG6H9RKY&address=".$address:
         $this->host."/api?module=account&action=tokentx&page=1&offset=200&apikey=6CS7J3VWEWVN3N2SXQHX2WHMC5KG6H9RKY&contractaddress=".$contractaddress."&tag=latest&address=".$address; 
          $result=$this->curl_request($post_url);
		 //var_dump($result);
		// var_dump($post_url);
          $json=json_decode($result,true);
          if(isset($json['status'])&&$json['status']=="1"){
              $isOk=true;
              $complete = [];//交易完成

              foreach ($json['result'] as $k=>$v){
            //  var_dump($v);
                  if($side=='out' && $v['from'] == strtolower( $address))
                  {//提现 1
                     $complete[$k]['from'] =$address;
					 $complete[$k]['to'] = $v['to'];
                  }
				  else if($side=='in' && $v['to'] == strtolower( $address))
                  { //充值 0
                      $complete[$k]['from'] = $v['from'];
					  $complete[$k]['to'] = $address;
                  }else{
                  	continue;
                  	//非本系统的账号
                  	//
                     // $complete[$k]['incoming'] = 0;
					 //   return ['code'=>500,'r'=>'非法记录'];
                  }
                  $complete[$k]['amount'] = Utils::weiToEth($v['value'],$decimals);
                  $complete[$k]['state'] =0; //$v['txreceipt_status']; //交易状态 0进行中 1已完成
                  $complete[$k]['time'] = date('Y-m-d H:i:s', $v['timeStamp']);
                  $complete[$k]['txid'] = $v['hash'];
				  $complete[$k]['confirmations'] = $v['confirmations'];
                  $complete[$k]['miner_fee'] =Utils::weiToEth($v['gasPrice'] *$v['gasUsed']);
              }
              //$ongoing=[];
              $history_list = $complete;//array_merge($complete,$ongoing);

			  return ['code'=>0,'txlist'=>$history_list];
          }
		  else{
			     return ['code'=>500,'r'=>$result,'url'=>$post_url,'contract'=>$contractaddress];
		     }
		 return ['code'=>200,'r'=>$result,'url'=>$post_url,'contract'=>$contractaddress ];
    }
 
 
    public function transfer($from,$to,$amount,$private_keys,$decimals,$contractaddress=''){
		 $client = new EthereumClient([
		     'base_uri' => $this->infura_host,
		     'timeout' => 120,
		 ]);

		// var_dump($from,$to,$amount,$private_keys,$contractaddress);
		 
		 $client->addPrivateKeys([$private_keys]);
		 if(empty($contractaddress)){
			 // 2. 建立您的交易
			 $trans = [
			     "from" => $from,
			     "to" => $to,
			     "value" => Utils::ethToWei($amount,$decimals, true),
			     "data" => '0x',
			 ];
		 }
		 else{
			$trans = [
			    "from" => $from,
			    "to" => $contractaddress,//合约地址
			    "value" => '0x0',
			//    "data" => '0x',
			]; 
			//tranfer的abi名称
			$str = "transfer(address,uint256)";
			//SHA-3，之前名为Keccak算法，是一个加密杂凑算法。
			$hash = Keccak::hash("transfer(address,uint256)",256);
			$hash_sub = mb_substr($hash,0,8,'utf-8');
			//接收地址
			$fill_from = Tool::fill0(Utils::remove0x($to));
			//转账金额
			$num10 = Utils::ethToWei($amount,$decimals);
			$num16 = Utils::decToHex($num10);
			$fill_num16 = Tool::fill0(Utils::remove0x($num16));
			
			//开始拼接
			$trans['data'] = "0x" . $hash_sub . $fill_from . $fill_num16;
		 }
		try {
		 // 你可以设定汽油，nonce，gasprice
		 
			 $trans['gasPrice'] = $client->eth_gasPrice();
			 $trans['gas'] =$client->eth_estimateGas($trans); //dechex(hexdec($client->eth_estimateGas($trans))* 1.2);;
			 $trans['nonce'] = $client->eth_getTransactionCount($from, 'pending');
			 
			var_dump(hexdec($client->eth_estimateGas($trans)),hexdec($client->eth_gasPrice()));die();
				// 3. 发送您的交易
				// 如果需要服务器，也可以使用eth_sendTransaction
			//	$txid = $client->sendTransaction($trans);
			} catch (\Throwable $e) {
				return ['code'=>500,'r'=>$e->getMessage()];
			}
			// 4. 如果没有错的话
			// 你会在这里看到txid。喜欢 string(66) "0x1adcb80b413bcde285f93f0274e6cf04bc016e8813c8390ff31a6ccb43e75f51"
			//print_r($txid);
			// 5. 你会…
			// https://ethereum.gitbooks.io/frontier-guide/content/rpc.html#eth_gettransactionreceipt
			//print_r($client->eth_getTransactionReceipt($txid));
			//
		return ['code'=>0,'txid'=>$txid,'miner_fee'=>$trans['gasPrice']];
    }
	
	public function add_user(){
		$client = new EthereumClient($this->infura_host);
		// You can to create an address offline
		list($address, $private_key) = $client->newAccount();
		//var_dump($address, $privateKey);
			return ['code'=>0,'address'=>$address,'private_key' => $private_key];
	}
		
    //请求网络
    public function curl_request($url,$post=false,$param=[],$https=true){
        //curl_init 初始化的时候传递url
        $ch = curl_init($url);

        //curl_setopt 设置一些请求选项，当然get是默认的也是最好处理的
        if($post){
            //设置请求方式和请求参数，post请求，要设置的类型就是bool型的，那么我们肯定是启用的设置为true，POSTFILEDS是传递的参数，它的第三个参数就是传递的参数可以为一个数组类型的也就是我们的param
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $param);  
        }
        // https请求，默认会进行验证
        if($https){
            //禁止从服务器端 验证客户端的证书，注意7.10开始默认为开启验证的！！！
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        }
        //curl_exec 执行请求会话（发送请求）
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		//本地代理
		//curl_setopt($ch, CURLOPT_PROXY,'127.0.0.1:1080');
        $result = curl_exec($ch); 
        //curl_close 关闭请求会话
        curl_close($ch);
        return $result;
    }

}