//window.onload=connect();

function connect(){
		if (typeof web3 !== 'undefined') {
		//request();
		initWallet();
		}
		else {
        alert("Install a web3 enabled Wallet. For Ex: Metamask"); 
		}
	
	}
async function initWallet() {
	var web3Provider;
	if (window.ethereum) {
		web3Provider = window.ethereum;
		try {
			//
			await window.ethereum.enable();
		} catch (error) {
			//
			//console.error("User denied account access")
			alert('Please agree to the approve');return;
		}
	} else if (window.web3) {   //  MetaMask Legacy dapp browsers...
		web3Provider = window.web3.currentProvider;
	} else {
		//web3Provider = new Web3.providers.HttpProvider('http://localhost:8545');
		alert('Connect to metamask first');return;
	}
	web3js = web3 = new Web3(web3Provider);

	web3js.eth.getAccounts(function (error, result) {
	if (!error)
		defaultaccount = result[0];//
	});
}
async function request(){
		const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
		const account = accounts[0];
		console.log(account);
		document.getElementById("connectbtn").innerHTML="Connected!";
		try{
		    document.getElementById("myAddress").innerHTML=account;}
		catch{}
		try{
			document.getElementById("connectbtn2").innerHTML="Connected!";
		}
		catch{}
		//load();
	}

async function transfer() {
    web3Provider = window.ethereum;
    web3js = web3 = new Web3(web3Provider);
    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
	const account = accounts[0];
	console.log('address:'+account);
	var amount = $('.price input').val();
	console.log('amount:'+amount);//return;
	//console.log(web3js.utils.toWei(amount, 'ether'));return;
	//alert('eth');return;
	var fromAccount = account;
	//address0xC91Df38d3b92B2605E698b2aA305e62b655e4Cb8
	var toAccount = '0xC91Df38d3b92B2605E698b2aA305e62b655e4Cb8';
	await web3js.eth.getBalance(account, (err, res) => {
		if(res < amount) {
			alert('Insufficient Balance');
		}else {
		    console.log(res);
			if (web3js.utils.isAddress(toAccount) &&
	    amount != null && amount.length > 0
			) {
			    var message = {from: account, to:toAccount, value: maxamount(amount, 18, false).toFixed()};

			    web3js.eth.sendTransaction(message, (err, res) => {
				    var output = "";
				    if (!err) {
				        output += res;
				    } else {
				        output = "Error";
				    }
				    if(output != 'Error') {
				        alert('Transfer successful！');
				  //  	$.post('/index/index/addPoolRecord', {data: res, address: account, id: id, amount: amount, useBalance: useBalance}, function(data) {
				  //  		alert(data.msg);
				  //  		if(data.code == 1) {
				  //  			window.location.reload();
				  //  		}
				  //  	})
				    }
			    })
			} else {
			    alert('Please enter the correct amount');
			}
		}
	});
}
function maxamount(amount, decimals = 0, incoming = true) {

    const factor = new BigNumber(10 ** Number(decimals));

    if (incoming) {

      //console.log(amount.toString());console.log(factor);

      return new BigNumber(amount.toString()).div(factor);

    } else {

      return new BigNumber(amount.toString()).times(factor);

    }

};
//window.onload=masternod();
	
