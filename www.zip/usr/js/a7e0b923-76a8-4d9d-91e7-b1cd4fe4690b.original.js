(function(d, s, id){
  var js, tdjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)){ return; }
  js = d.createElement(s); js.id = id;
  js.onload = function(){
    TraverseRetargeting.init({advertiserId: "63258dae-37ae-4c4b-a900-c437fdebb48b"});
    TraverseRetargeting.include({
      campaignId: "1521d049-c74a-4905-a124-f4a4ac47174b",
      advertiserProperties: {
        e: "6LECmLGZ3AaYJBhUDPxHY6vpr9x5PFBOINudY0qTHhVLdddlC2loQdcil4ULAGmn8UbT7yfn0eq706hVhFTlAWX8kVW22VWihijUCSFhCCD-305v39zgvmfaPRqtDUCUDkGgSYqZW5g3va5vQcgDks4VpsdpL2vtXXMXtpTbjd2O-aamS9p6X37ZOicBdPCmZC6906YINNaPh3DqnBN56B0EYEfGwmqx04fIum4xtI1pctL9I8gCXvytQCRci3K_Tg-eFunRuOReKBzuwdvYoZ8sNnKIguXFM6Y04f_3-PsKHOhuCbjfRjZYltfpr09rpiqZavIpF6Nm2M1leUaT7zGC9OZ1msbKdQwkw_i7e6DPXAOAEqLJfmMEl-0l18cp_pEuOC5ODdFcmpMfiYLRotuOPqi63omgY0AQb9bYtr3BjpnXnITPsE-TehhsLtKWXd0nrvDHaJlwcIOv3m5Q5IQQfnXc2bmpq_zu0tzYC1cBufxit_YjuztfVCYvcbWPODxBLTQUmA3_WEda-00LRnzGnsFF8mTjMJVMGUDCirSvsY3pBQMwmRJQL8vEc5K0R1t57BAmTDygKX3Z5qzRYzgPyCtyMBD9JjkCf6JzfELs-H9qk3S6-s7b3bterKOThzrGp3zlgU0ZANuBSmBwV2oJyFS10eLntGu-iKP4_UlaVJ32NQAv2Lg-DRCdULH0011QewoN6D3GKjaHM5ldcL8zTr1kssiymF2bsCd4J82u0q947I01OvpiyP25czX_zhVyQgvN6SUFZ6RfECmzWe2LxItTIk3r7H7pyjg1skofA7mTq8pDdMjikrPwfWBns4GT57DpjB0ipiB1hXoqIBN9YWPiaJvUwkiWDK80Ixn63VckrvykHRKrW4mRrroLtD5ulboMvyrfZ5y9o8tOTQCTLcLmJT7LwdIo_STrSm0Xv744FrGwQmU-1yCNs1_nd_D3taT5ije1mTrdCh8amGBufIasyDTbhKSc_TSfkJ3ATDPjZZmVYdX0OL0SPL14Bp88cvWnFLzdFDCBwaWZqFncoRX0dOaZKse-slqLwFCt0odT3WH7kPV87zNK5ZnfbVmvT2PeBJda1uv0Zj23spaegASDw_6EiMsPnt04kuuKKB9WxCQ2rDJBmDo",
        l: d.URL,
        r: d.referrer
      }
    });
  };
  js.src = "https://static.traversedlp.com/v1/retargeting.js";
  tdjs.parentNode.insertBefore(js, tdjs);
}(document, "script", "td-tdjs"));
