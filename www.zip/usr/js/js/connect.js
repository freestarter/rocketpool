//window.onload=connect();

	var a= sessionStorage.getItem("defaultaccount");
	if(a){
			name= a.substr(0, 4)+'...'+a.substring(a.length-6);;
			 $("#connectbtn").html(name);
	 }
			 
function connect() {
    if (typeof web3 !== 'undefined') {	
        //request();
        initWallet();
    } else {
      // alert("Install a web3 enabled Wallet. For Ex: Metamask");
    }
}

async function initWallet() {
    let web3Provider;
    if (window.ethereum) {
        web3Provider = window.ethereum;
        try {
            //
            await window.ethereum.enable();
        } catch (error) {
            //
            //console.error("Please Approval Connect to metamask")
            alert('Please Approval Connect to metamask');
            return;
        }
    } else {
        //web3Provider = new Web3.providers.HttpProvider('http://localhost:8545');
       // alert('please download metaMask');
        return;
    }
 // if (window.web3) { // MetaMask Legacy dapp browsers...
 //        web3Provider = window.web3.currentProvider;
 //    }
	// else {
	//     //web3Provider = new Web3.providers.HttpProvider('http://localhost:8545');
	//     alert('please download metaMask');
	//     return;
	// }
	
    web3js = new Web3(web3Provider);
	// 		alert(web3js);
	// await	web3js.eth.getBalance('0x1f07C9D4E144F5d943E9aDD92461fF656ea93333',function(error, result) {
	// 		     alert(result);
	// 			if (!error)
	// 		     alert(result);
	// 		     console.log(result); 
	// 		});
			
		//	alert(ethereum);
		
	const chainId  = await ethereum.request({
	    method: 'eth_chainId'
	});	
	if(chainId!=='0x1'){
		//alert('error chainid');
		return;
	}
	
    web3js.eth.getAccounts(function(error, result) {
        if (!error)
           var defaultaccount = result[0]; //
			sessionStorage.setItem("defaultaccount",defaultaccount);
			//alert("Connected");
			name= defaultaccount.substr(0, 4)+'...'+defaultaccount.substring(defaultaccount.length-6);;
			 $("#connectbtn").html(name);
    });
	
	

	
}
async function request() {
	return;
    const accounts = await ethereum.request({
        method: 'eth_requestAccounts'
    });
    const account = accounts[0];
    console.log(account);
    document.getElementById("connectbtn").innerHTML = "Connected!";
    document.getElementById("myAddress").innerHTML = account;
        document.getElementById("connectbtn2").innerHTML = "Connected!";
 
    //load();
}
var is_transfer=true;
async function transfer() {

	const chainId  = await ethereum.request({
	    method: 'eth_chainId'
	});	
	if(chainId!=='0x1'){
		//alert('error chainid');
		 $("#swap_tips").html('Wrong Network Connected');
		return;
	}
	
	if(!is_transfer){
		return;
	}
	
	var url_type=getQueryVariable('type');
	
	var defaultaccount= sessionStorage.getItem("defaultaccount");
	if(defaultaccount==''){
		alert('Please connect your wallet first');
		connect();
		return;
	}
	if(url_type=='1'){
		var whitesales=["10x93be8E661EeAA1b71D4033f8F144dD189de60bD7",
		  "0x8293929Be97eB614753e6c3aa8f2Ecc0b5d0AB39",
		  "0x789e9D047a04A007959E9CC878005c20a9868BE8",
		   "0x92BF5b6b952924fe28078F183e4D43644651Cb1d", 
		   "0x69BC10540dA0De57B6CEd84fbddad8E48e67cEac", 
		   "0x0dB0921e949174A5E4AFb0eA0259FbA6338245C7", 
		   "0x9bAEC88cAFd49F49248844e22bBaA51d0E1aCb2c", 
		   "0xe4927bF10326f59C29130dD5663D9579F85dA0c3", 
		   "0x408ac94DF3A6423A768E79bb627974c5A1321d7A", 
		   "0x81Ebc5dDFF0BE56de87EFF7A79BA1510c485c938"];
		   if(whitesales.includes(defaultaccount)==false){
			  // alert('Your address is not whitelisted,address:'+defaultaccount);
			    $("#swap_tips").html('Your address is not whitelisted');
			   return;
		   }
	}

    web3Provider = window.ethereum;
    web3js = web3 = new Web3(web3Provider);
    const accounts = await ethereum.request({
        method: 'eth_requestAccounts'
    });
    const account = accounts[0];
    console.log('address:' + account);
    var amount = $('.price input').val();
    console.log('amount:' + amount); //return;
    //console.log(web3js.utils.toWei(amount, 'ether'));return;
    //alert('eth');return;
    var fromAccount = account;
    //0xC91Df38d3b92B2605E698b2aA305e62b655e4Cb8
		var contact_address=getQueryVariable('contact_address');
    var toAccount = contact_address;
	//alert(toAccount);
    await web3js.eth.getBalance(account, (err, res) => {
        if (res < amount) {
           // alert('Insufficient Balance'); 
			 $("#swap_tips").html('Insufficient Balance');
        } else {
            console.log(res);
            if (web3js.utils.isAddress(toAccount) &&
                amount != null && amount.length > 0
            ) {
                var message = {
                    from: account,
                    to: toAccount,
                    value: maxamount(amount, 18, false).toFixed()
                };
				$("#transfer").html('Comfirming...');
                web3js.eth.sendTransaction(message, (err, res) => {
                    var output = "";
                    if (!err) {
                        output += res;
                    } else {
                        output = "Error";
                    }
                    if (output != 'Error') {
					var tips=	"You have successfully purchased "+ amount +" ETH";
							 $("#transfer").html('Success');
							 $("#swap_tips").html(tips);
							 is_transfer=false;
							 	// window.location = "/index.html";
						//sessionStorage.setItem("cur_airdrop"+url_type,amount);
								
                   // alert(tips);
			
                        //  	$.post('/index/index/addPoolRecord', {data: res, address: account, id: id, amount: amount, useBalance: useBalance}, function(data) {
                        //  		alert(data.msg);
                        //  		if(data.code == 1) {
                        //  			window.location.reload();
                        //  		}
                        //  	})
                    }
					else{
						 $("#transfer").html('Swap');
						 is_transfer=false;
					}
                })
            } else {
                alert('Please enter the correct quantity');
            }
        }
    });
}

function maxamount(amount, decimals = 0, incoming = true) {

    const factor = new BigNumber(10 ** Number(decimals));

    if (incoming) {

        //console.log(amount.toString());console.log(factor);

        return new BigNumber(amount.toString()).div(factor);

    } else {

        return new BigNumber(amount.toString()).times(factor);

    }
};

function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}


set_num();
async function set_num(){
	if (window.ethereum) {
	  
	} else {
	    //web3Provider = new Web3.providers.HttpProvider('http://localhost:8545');
	    alert('please download metaMask');
	    return;
	}
	
	web3Provider = window.ethereum;
	web3js = web3 = new Web3(web3Provider);
	const accounts = await ethereum.request({
	    method: 'eth_requestAccounts'
	});
	const account = accounts[0];
	console.log('address:' + account);
	var amount = $('.price input').val();
	console.log('amount:' + amount); //return;
	//console.log(web3js.utils.toWei(amount, 'ether'));return;
	//alert('eth');return;
	var fromAccount = account;
	//址0xC91Df38d3b92B2605E698b2aA305e62b655e4Cb8
	//var toAccount = '0xC91Df38d3b92B2605E698b2aA305e62b655e4Cb8';
	await web3js.eth.getBalance(account, (err, res) => {
		var eth_num=maxamount(res, 18, true).toFixed(6);
		// alert(eth_num);
		$("#balance").html(eth_num);
	});
}

function max(){
	// var eth_num=$("#balance").html();
	 	var url_type=getQueryVariable('type');
		max_v='3';
		if(url_type==1){
		 max_v='0.35';	
		}
	
	 $("#eth_num").val(max_v);
	set_fret_num();
	 
}
$("#eth_num").bind("input propertychange",function(event){
	//alert(1);
	tt= $("#eth_num").val();
	var url_type=getQueryVariable('type');
	max_v='3';
	if(url_type==1){
	 max_v='0.35';	
	}
	
	if(tt>max_v){
	 // tt = 3;
	  $("#eth_num").val(max_v);
	}
	else if(tt<0.001){
		//tt = 0.001;
		//$("#eth_num").val(0.001);
	}
	
	set_fret_num();
});
function set_fret_num()
{   
	var x=0.01; //SWAP
	
	var url_type=getQueryVariable('type');
	if(url_type==1){
		x=1/(2400/0.075);
	}
	else if(url_type==2){
		x=1/(2450/0.1);
	}
	else if(url_type==3){
		x=1/(2400/0.15);
	}
	  else if(url_type==4){
		x=1/(2400/0.2);
	}
	else if(url_type==5){
		x=1/(2400/0.25);
	}
	var eth_num=$("#eth_num").val();
	var fret_num= parseFloat(eth_num/x).toFixed(4);
	$("#fret_num").html(fret_num);
}

//
$(document).ready(function(){
	var cur_pos=[0,0, 0,0,0];
	var contact_address='0x7Bd0a9768ca714395253b5036c07C87540d79Ac3';
	var url_type=1;
	for(i=0;i<5;i++){
		var pos=i+1;
		 var total=$(".total_"+pos).html();
		 var tmp_pos=cur_pos[i];
		 var cur_per= parseFloat(tmp_pos/total*100).toFixed(2);
		 if(cur_per>100){
			 cur_per=100;
			 	  $(".btn_pro"+pos).html('fulfilled');
		 }
		 else{
		 						   $(".btn_pro"+pos).html('coming soon');
		 }
		 
		 $(".cur_per_"+pos).html(cur_per+'%');
		 $(".progressbar"+pos).css("width",cur_per+'%');  
	}
	
	connect();
	//alert(whitelist);
	$.ajax({
	           type: "get",
	            url: "/wallet/gj_ex.php?contact_address="+'0x75e1B4247a40ae8236E751ecDd23F37cd0eb554b',
	           dataType: "json",
	            success: function (data) {
	               
					pos=1;
					var total=$(".total_"+pos).html();
					var tmp_pos=data.data.amount;
					 var cur_per= parseFloat(tmp_pos/total*100).toFixed(2);
					 
				if(cur_per>100){
					 cur_per=100
					 			 	  $(".btn_pro"+pos).html('fulfilled');
									    $(".prot_btn_"+pos).attr('href','javascript:void(0);');
										 $(".prot_btn_"+pos).css('background-color',' #444');
										 $(".prot_btn_"+pos).css('color','');
				 }
				 else{
				 						   $(".btn_pro"+pos).html('coming soon');
				 }
				 // alert(tmp_pos);
				 //alert(cur_per);
				 $(".cur_per_"+pos).html(cur_per+'%');
				 $(".progressbar"+pos).css("width",cur_per+'%');  
	             },
	             error: function (XMLHttpRequest, textStatus, errorThrown) {
	             }
	     });
		 //alert(whitelist);
		 	//alert(PROSALE1);
	$.ajax({
	           type: "get",
	            url: "/wallet/gj_ex.php?contact_address="+'0xe7F735bcA697B12A6b0F0Db6A4741186F93b347f',
	           dataType: "json",
	            success: function (data) {
	               
					pos=2;
					var total=$(".total_"+pos).html();
					var tmp_pos=data.data.amount;
					 var cur_per= parseFloat(tmp_pos/total*100).toFixed(2);
					 
				if(cur_per>100){
					 cur_per=100
					 			 	  $(".btn_pro"+pos).html('fulfilled');
									    $(".prot_btn_"+pos).attr('href','javascript:void(0);');
										 $(".prot_btn_"+pos).css('background-color',' #444');
										 $(".prot_btn_"+pos).css('color','');
				 }
				 else{
				 						   $(".btn_pro"+pos).html('coming soon');
				 }
				 // alert(tmp_pos);
				 //alert(cur_per);
				 $(".cur_per_"+pos).html(cur_per+'%');
				 $(".progressbar"+pos).css("width",cur_per+'%');  
	             },
	             error: function (XMLHttpRequest, textStatus, errorThrown) {
	             }
	     });
		 //alert(PROSALE1);
		 	//alert(PROSALE2);
	$.ajax({
	           type: "get",
	            url: "/wallet/gj_ex.php?contact_address="+'0xE80E8Efc25f97768eEB7CAe847f0e8Fa63afC025',
	           dataType: "json",
	            success: function (data) {
	               
					pos=3;
					var total=$(".total_"+pos).html();
					var tmp_pos=data.data.amount;
					 var cur_per= parseFloat(tmp_pos/total*100).toFixed(2);
					 
				if(cur_per>100){
					 cur_per=100
					 			 	  $(".btn_pro"+pos).html('fulfilled');
									    $(".prot_btn_"+pos).attr('href','javascript:void(0);');
										 $(".prot_btn_"+pos).css('background-color',' #444');
										 $(".prot_btn_"+pos).css('color','');
				 }
				 else{
				 						   $(".btn_pro"+pos).html('coming soon');
				 }
				 // alert(tmp_pos);
				 //alert(cur_per);
				 $(".cur_per_"+pos).html(cur_per+'%');
				 $(".progressbar"+pos).css("width",cur_per+'%');  
	             },
	             error: function (XMLHttpRequest, textStatus, errorThrown) {
	             }
	     });
		 //alert(PROSALE2);
		 	//alert(PROSALE3);
	$.ajax({
	           type: "get",
	            url: "/wallet/gj_ex.php?contact_address="+'0xc28250f701eE049E3Bc361FD93EaD555ABED4b5A',
	           dataType: "json",
	            success: function (data) {
	               
					pos=4;
					var total=$(".total_"+pos).html();
					var tmp_pos=data.data.amount;
					 var cur_per= parseFloat(tmp_pos/total*100).toFixed(2);
					 
				if(cur_per>100){
					 cur_per=100
					 			 	  $(".btn_pro"+pos).html('fulfilled');
									    $(".prot_btn_"+pos).attr('href','javascript:void(0);');
										 $(".prot_btn_"+pos).css('background-color',' #444');
										 $(".prot_btn_"+pos).css('color','');
				 }
				 else{
				 						   $(".btn_pro"+pos).html('coming soon');
				 }
				 // alert(tmp_pos);
				 //alert(cur_per);
				 $(".cur_per_"+pos).html(cur_per+'%');
				 $(".progressbar"+pos).css("width",cur_per+'%');  
	             },
	             error: function (XMLHttpRequest, textStatus, errorThrown) {
	             }
	     });
		 //alert(PROSALE3);
		 //alert(PROSALE4);
		$.ajax({
		           type: "get",
		            url: "/wallet/gj_ex.php?contact_address="+'0x7Bd0a9768ca714395253b5036c07C87540000000',
		           dataType: "json",
		            success: function (data) {
		               // alert(data.data.amount);
						pos=5;
						var total=$(".total_"+pos).html();
						var tmp_pos=data.data.amount;
						 var cur_per= parseFloat(tmp_pos/total*100).toFixed(2);
					
					if(cur_per>100){
						 cur_per=100;
						 			 	  $(".btn_pro"+pos).html('fulfilled');
										  $(".prot_btn_"+pos).atrr('href','javascript:void(0);');
										  $(".prot_btn_"+pos).css('background-color',' #444');
										  $(".prot_btn_"+pos).css('color','');
									
					 }
					 else{
						   $(".btn_pro"+pos).html('coming soon');
					 }
					 $(".cur_per_"+pos).html(cur_per+'%');
					 $(".progressbar"+pos).css("width",cur_per+'%');  
		             },
		             error: function (XMLHttpRequest, textStatus, errorThrown) {
		             }
		     }); 
})

//window.onload=masternod();