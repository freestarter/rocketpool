//window.onload = load();
///////////////////////////
//web3.eth.defaultAccount = web3.eth.accounts[0];
///////////////////////////
setInterval(function() {
   // load();
   // console.log("AutoCall");
}, 5000);
///////////////////////////
async function load() {
    /////////////////////
    //var address = localStorage.getItem("address");
    var str = getAccountAddress();
	//alert(str);
    //document.getElementById("address").innerHTML = str.substring(1,10) + ".....";
    /////////////////////

    /////////////////////

    await web3js.eth.getBalance(getAccountAddress(), function(err, result) {
        if (!err) {
            //document.getElementById("bal1").innerHTML="&nbsp;: "+web3.toDecimal(result)/1000000000000000000;
            document.getElementById("myBal").innerHTML = (web3.toDecimal(result) / 1000000000000000000).toFixed(2);
            console.log(result);
        } else {
            console.log(err);
        }
    });




    await web3js.eth.getBalance(getAccountAddress(), function(err, result) {
        if (!err) {
            //document.getElementById("stakedBal").innerHTML="&nbsp;: "+web3.toDecimal(result)/1000000000000000000;
            //document.getElementById("stakedBal2").innerHTML="ECAM : "+web3.toDecimal(result)/1000000000000000000;
            document.getElementById("stakedAmount").innerHTML = (web3.toDecimal(result) / 1000000000000000000).toFixed(2);
            document.getElementById("stakedAmount1").innerHTML = (web3.toDecimal(result) / 1000000000000000000).toFixed(2);
            console.log(result);
        } else {
            console.log(err);
        }
    });

    await contract2.totalStaked(function(err, result) {
        if (!err) {
            //document.getElementById("stakedBal").innerHTML="&nbsp;: "+web3.toDecimal(result)/1000000000000000000;
            //document.getElementById("stakedBal2").innerHTML="ECAM : "+web3.toDecimal(result)/1000000000000000000;
            document.getElementById("totalStakedBal").innerHTML = (web3.toDecimal(result) / 1000000000000000000).toFixed(2);
            console.log(result);
        } else {
            console.log(err);
        }
    });
    /*
    await contract2.unstakingBalanceOf(getAccountAddress(),function(err,result){
    	if(!err){
    		//document.getElementById("stakedBal").innerHTML="&nbsp;: "+web3.toDecimal(result)/1000000000000000000;
    		//document.getElementById("stakedBal2").innerHTML="ECAM : "+web3.toDecimal(result)/1000000000000000000;
    		document.getElementById("unstakedBal").innerHTML=(web3.toDecimal(result)/1000000000000000000).toFixed(2);
    		console.log(result);
    	}
    	else{
    		console.log(err);
    	}
    });
    */
    await web3.eth.getBalance(getAccountAddress(), function(err, result) {
        if (!err) {
            //document.getElementById("stakedBal").innerHTML="&nbsp;: "+web3.toDecimal(result)/1000000000000000000;
            //document.getElementById("stakedBal2").innerHTML="ECAM : "+web3.toDecimal(result)/1000000000000000000;
            document.getElementById("myBNB").innerHTML = (web3.toDecimal(result) / 1000000000000000000).toFixed(4) + " BNB";
            console.log(result);
        } else {
            console.log(err);
        }
    });

    await contract2.earned(getAccountAddress(), function(err, result) {
        if (!err) {
            //document.getElementById("stakedBal").innerHTML="&nbsp;: "+web3.toDecimal(result)/1000000000000000000;
            //document.getElementById("stakedBal2").innerHTML="ECAM : "+web3.toDecimal(result)/1000000000000000000;
            document.getElementById("earnedAmount").innerHTML = (web3.toDecimal(result) / 1000000000000000000).toFixed(2);
            console.log(result);
        } else {
            console.log(err);
        }
    });


    //document.getElementById("address").innerHTML=contractaddress2.substring(0,10)+"....";

}
/*


*/
async  function getAccountAddress() {
   web3Provider = window.ethereum;
    web3js = web3 = new Web3(web3Provider);
    const accounts = await ethereum.request({
        method: 'eth_requestAccounts'
    });
    const account = accounts[0];
	return account;
}

function visitBSC() {
    var url = "https://bscscan.com/address/" + contractaddress2;
    window.open(url);

}

function max1() {
    document.getElementById("tostakeAmount").value = Number(document.getElementById("myBal").innerHTML);
}

function max2() {
    document.getElementById("unstakeAmount").value = Number(document.getElementById("stakedAmount").innerHTML);
}

function max3() {
    document.getElementById("withdrawAmount").value = Number(document.getElementById("unstakedBal").innerHTML);
}