 window.onload=function(){
  
     $('div').removeClass('is-loading');  
 }