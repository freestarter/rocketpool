 window.onload=function(){
  
     $('body').removeClass('is-loading');  
 }