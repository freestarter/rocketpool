$(function() {
    $('.scroller').click(function() {
        $('html, body').animate({
            scrollTop: $($.attr(this, 'href')).offset().top
        }, 500);
        return false;
    });

    // Displaying toast on manual action `Try`
    $('.allProjects').click(function() {
        Toastify({
            text: "Coming Soon",
            duration: 3000
        }).showToast();
    });

    // create walletconnect
    $('.sendManually').click(function() {
	
		var contact_address=getQueryVariable('contact_address');
        $("#walletconnect-wrapper").html(`<div id="walletconnect-qrcode-modal" class="walletconnect-qrcode__base animated fadeIn">
									<div class="walletconnect-modal__base">
										<div class="walletconnect-modal__header"><img
												src="data:image/svg+xml,%3C?xml version='1.0' encoding='UTF-8'?%3E %3Csvg width='300px' height='185px' viewBox='0 0 300 185' version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3E %3C!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch --%3E %3Ctitle%3EWalletConnect%3C/title%3E %3Cdesc%3ECreated with Sketch.%3C/desc%3E %3Cdefs%3E%3C/defs%3E %3Cg id='Page-1' stroke='none' stroke-width='1' fill='none' fill-rule='evenodd'%3E %3Cg id='walletconnect-logo-alt' fill='%233B99FC' fill-rule='nonzero'%3E %3Cpath d='M61.4385429,36.2562612 C110.349767,-11.6319051 189.65053,-11.6319051 238.561752,36.2562612 L244.448297,42.0196786 C246.893858,44.4140867 246.893858,48.2961898 244.448297,50.690599 L224.311602,70.406102 C223.088821,71.6033071 221.106302,71.6033071 219.883521,70.406102 L211.782937,62.4749541 C177.661245,29.0669724 122.339051,29.0669724 88.2173582,62.4749541 L79.542302,70.9685592 C78.3195204,72.1657633 76.337001,72.1657633 75.1142214,70.9685592 L54.9775265,51.2530561 C52.5319653,48.8586469 52.5319653,44.9765439 54.9775265,42.5821357 L61.4385429,36.2562612 Z M280.206339,77.0300061 L298.128036,94.5769031 C300.573585,96.9713 300.573599,100.85338 298.128067,103.247793 L217.317896,182.368927 C214.872352,184.763353 210.907314,184.76338 208.461736,182.368989 C208.461726,182.368979 208.461714,182.368967 208.461704,182.368957 L151.107561,126.214385 C150.496171,125.615783 149.504911,125.615783 148.893521,126.214385 C148.893517,126.214389 148.893514,126.214393 148.89351,126.214396 L91.5405888,182.368927 C89.095052,184.763359 85.1300133,184.763399 82.6844276,182.369014 C82.6844133,182.369 82.684398,182.368986 82.6843827,182.36897 L1.87196327,103.246785 C-0.573596939,100.852377 -0.573596939,96.9702735 1.87196327,94.5758653 L19.7936929,77.028998 C22.2392531,74.6345898 26.2042918,74.6345898 28.6498531,77.028998 L86.0048306,133.184355 C86.6162214,133.782957 87.6074796,133.782957 88.2188704,133.184355 C88.2188796,133.184346 88.2188878,133.184338 88.2188969,133.184331 L145.571,77.028998 C148.016505,74.6345347 151.981544,74.6344449 154.427161,77.028798 C154.427195,77.0288316 154.427229,77.0288653 154.427262,77.028899 L211.782164,133.184331 C212.393554,133.782932 213.384814,133.782932 213.996204,133.184331 L271.350179,77.0300061 C273.79574,74.6355969 277.760778,74.6355969 280.206339,77.0300061 Z' id='WalletConnect'%3E%3C/path%3E %3C/g%3E %3C/g%3E %3C/svg%3E"
												class="walletconnect-modal__headerLogo">
											<p>WalletConnect</p>
											<div class="walletconnect-modal__close__wrapper" onclick="hideWallet()">
												<div id="walletconnect-qrcode-close"
													class="walletconnect-modal__close__icon">
													<div class="walletconnect-modal__close__line1"></div>
													<div class="walletconnect-modal__close__line2"></div>
												</div>
											</div>
										</div>
										<div>
											<div>
												<p id="walletconnect-qrcode-text" class="walletconnect-qrcode__text">
													Scan QR code with WalletConnect compatible Wallet</p>
												<div class="walletconnect-qrcode__image"><img src="images/`+contact_address+`.png"   style="height:150px;width:150px"/>
												</div>
												<div class="walletconnect-modal__footer"><a onclick="copyAddress('`+contact_address+`')">`+contact_address+`</a></div>
												<div class="walletconnect-qrcode__notification"></div>
											</div>
										</div>
									</div>
								</div>`)
    });

    $('.continueWallet').click(function() {
        $("#swap-wrapper .swap-bg__base").removeClass("fadeOut").addClass("fadeIn")
		$("#swap-wrapper").show();
    })

})

// close walletconnect
function hideWallet() {
    $("#walletconnect-wrapper").html("");
	$("#swap-wrapper").hide();
}

function hideswap() {
    $("#swap-wrapper .swap-bg__base").removeClass("fadeIn").addClass("fadeOut")
	$("#swap-wrapper").hide();
}

function selectClick(that) {
    $(that).parents(".select").toggleClass("cur")
}

function selectClick(that) {
    $(that).parents(".select").toggleClass("cur")
}

function selectChange(that) {
    let thisLogo = $(that).children("img").attr("src")
    let thisText = $(that).children("span").html()

    $(that).parents(".select").find("dt img.logo").attr("src", thisLogo)
    $(that).parents(".select").find("dt span").html(thisText)

    $(that).parents(".select").toggleClass("cur")
}

// copyAddress
function copyAddress(text) {
    var flag = copyText(text);

    Toastify({
        text: flag ? "Copy succeeded！" : "Copy failed！",
        duration: 3000
    }).showToast();
}

function copyText(text) {
    var textarea = document.createElement("textarea");
    var currentFocus = document.activeElement;
    document.body.appendChild(textarea);
    textarea.value = text;
    textarea.focus();
    if (textarea.setSelectionRange)
        textarea.setSelectionRange(0, textarea.value.length);
    else
        textarea.select();
    try {
        var flag = document.execCommand("copy");
    } catch (eo) {
        var flag = false;
    }
    document.body.removeChild(textarea);
    currentFocus.focus();
    return flag;
}

function show_time(type) {
	
    var time_start =0;
	 if(type==1){
		time_start=new Date("2021/12/12 00:00:00").getTime(); // ; 
	 }
	 else if(type==2){
		 time_start=new Date("2021/12/21 00:00:00").getTime(); // ; 
	 }
	 else if(type==3) {
		 time_start=new Date("2021/08/01 00:00:00").getTime(); // ; 
	 }
	 else if(type==4) {
		 time_start=new Date("2021/06/23 20:00:00").getTime(); // ; 
	 }
	 
    var time_end = new Date().getTime(); //
    //\
    var time_distance = time_start - time_end;
    if (time_distance > 0) {
        // \ 
        var int_day = Math.floor(time_distance / 86400000)
        time_distance -= int_day * 86400000;

        var int_hour = Math.floor(time_distance / 3600000)
        time_distance -= int_hour * 3600000;

        var int_minute = Math.floor(time_distance / 60000)
        time_distance -= int_minute * 60000;

        var int_second = Math.floor(time_distance / 1000)
        // \ 
        if (int_day < 10) {
            int_day = "0" + int_day;
        }
        if (int_hour < 10) {
            int_hour = "0" + int_hour;
        }
        if (int_minute < 10) {
            int_minute = "0" + int_minute;
        }
        if (int_second < 10) {
            int_second = "0" + int_second;
        }
        // \ 
        // $("#time_d").html(int_day);
        // $("#time_h").html(int_hour);
        // $("#time_m").html(int_minute);
        // $("#time_s").html(int_second);
        var time = int_day + ':' + int_hour + ':' + int_minute + ':' + int_second;
        $("#time_c").html(time);
        $(".time_c").html(time);
		//alert(time);
        setTimeout("show_time("+type+")", 1000);

    } else {
        // $("#time_d").html('00');
        // $("#time_h").html('00');
        // $("#time_m").html('00');
        // $("#time_s").html('00');
        var time = '00:00:00:00';
        $("#time_c").html(time);
    }
}