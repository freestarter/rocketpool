	const web3 = new Web3(window.ethereum);

	let contractaddress1 = "0x7C6D5B88522d1D178f1810b6B075aB96243609D4"; //token contract
	let abi1 = [{
	    "constant": true,
	    "inputs": [],
	    "name": "name",
	    "outputs": [{
	        "name": "",
	        "type": "string"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "spender",
	        "type": "address"
	    }, {
	        "name": "value",
	        "type": "uint256"
	    }],
	    "name": "approve",
	    "outputs": [{
	        "name": "",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "totalSupply",
	    "outputs": [{
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "from",
	        "type": "address"
	    }, {
	        "name": "to",
	        "type": "address"
	    }, {
	        "name": "value",
	        "type": "uint256"
	    }],
	    "name": "transferFrom",
	    "outputs": [{
	        "name": "",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "decimals",
	    "outputs": [{
	        "name": "",
	        "type": "uint8"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "spender",
	        "type": "address"
	    }, {
	        "name": "addedValue",
	        "type": "uint256"
	    }],
	    "name": "increaseAllowance",
	    "outputs": [{
	        "name": "success",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "unpause",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "to",
	        "type": "address"
	    }, {
	        "name": "value",
	        "type": "uint256"
	    }],
	    "name": "mint",
	    "outputs": [{
	        "name": "",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "value",
	        "type": "uint256"
	    }],
	    "name": "burn",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "isPauser",
	    "outputs": [{
	        "name": "",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "paused",
	    "outputs": [{
	        "name": "",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "renouncePauser",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "name": "owner",
	        "type": "address"
	    }],
	    "name": "balanceOf",
	    "outputs": [{
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "from",
	        "type": "address"
	    }, {
	        "name": "value",
	        "type": "uint256"
	    }],
	    "name": "burnFrom",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "addPauser",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "pause",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "symbol",
	    "outputs": [{
	        "name": "",
	        "type": "string"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "addMinter",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "renounceMinter",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "spender",
	        "type": "address"
	    }, {
	        "name": "subtractedValue",
	        "type": "uint256"
	    }],
	    "name": "decreaseAllowance",
	    "outputs": [{
	        "name": "success",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "name": "to",
	        "type": "address"
	    }, {
	        "name": "value",
	        "type": "uint256"
	    }],
	    "name": "transfer",
	    "outputs": [{
	        "name": "",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "isMinter",
	    "outputs": [{
	        "name": "",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "name": "owner",
	        "type": "address"
	    }, {
	        "name": "spender",
	        "type": "address"
	    }],
	    "name": "allowance",
	    "outputs": [{
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "inputs": [{
	        "name": "name",
	        "type": "string"
	    }, {
	        "name": "symbol",
	        "type": "string"
	    }, {
	        "name": "decimals",
	        "type": "uint8"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "constructor"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "MinterAdded",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "MinterRemoved",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": false,
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "Paused",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": false,
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "Unpaused",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "PauserAdded",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "PauserRemoved",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "name": "from",
	        "type": "address"
	    }, {
	        "indexed": true,
	        "name": "to",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "name": "value",
	        "type": "uint256"
	    }],
	    "name": "Transfer",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "name": "owner",
	        "type": "address"
	    }, {
	        "indexed": true,
	        "name": "spender",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "name": "value",
	        "type": "uint256"
	    }],
	    "name": "Approval",
	    "type": "event"
	}];
	let contract1 = web3.eth.contract(abi1).at(contractaddress1);

	let contractaddress2 = "0x2548f1D042d30372CeD81a8fA82627F2CF6C583f"; //stake contract
	let abi2 = [{
	    "inputs": [{
	        "internalType": "address",
	        "name": "_owner",
	        "type": "address"
	    }, {
	        "internalType": "address",
	        "name": "_stakingToken",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "constructor"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": false,
	        "internalType": "address",
	        "name": "oldOwner",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "internalType": "address",
	        "name": "newOwner",
	        "type": "address"
	    }],
	    "name": "OwnerChanged",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": false,
	        "internalType": "address",
	        "name": "newOwner",
	        "type": "address"
	    }],
	    "name": "OwnerNominated",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": false,
	        "internalType": "bool",
	        "name": "isPaused",
	        "type": "bool"
	    }],
	    "name": "PauseChanged",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": false,
	        "internalType": "address",
	        "name": "token",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "Recovered",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": false,
	        "internalType": "uint256",
	        "name": "reward",
	        "type": "uint256"
	    }],
	    "name": "RewardAdded",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "internalType": "address",
	        "name": "user",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "internalType": "uint256",
	        "name": "reward",
	        "type": "uint256"
	    }],
	    "name": "RewardPaid",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "internalType": "address",
	        "name": "user",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "internalType": "uint256",
	        "name": "reward",
	        "type": "uint256"
	    }],
	    "name": "RewardWithdrawn",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": false,
	        "internalType": "uint256",
	        "name": "newDuration",
	        "type": "uint256"
	    }],
	    "name": "RewardsDurationUpdated",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "internalType": "address",
	        "name": "user",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "Staked",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "internalType": "address",
	        "name": "user",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "Unstaked",
	    "type": "event"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "internalType": "address",
	        "name": "user",
	        "type": "address"
	    }, {
	        "indexed": false,
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "Withdrawn",
	    "type": "event"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "acceptOwnership",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "addRewardSupply",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "name": "allAddress",
	    "outputs": [{
	        "internalType": "address",
	        "name": "",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "balanceOf",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "earned",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "exit",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "i",
	        "type": "uint256"
	    }],
	    "name": "getAddresses",
	    "outputs": [{
	        "internalType": "address",
	        "name": "",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "getAddressesLength",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "lastPauseTime",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "lockInReward",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "minStakeBalance",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "nextRewardApplicableTime",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "address",
	        "name": "_owner",
	        "type": "address"
	    }],
	    "name": "nominateNewOwner",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "nominatedOwner",
	    "outputs": [{
	        "internalType": "address",
	        "name": "",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "owner",
	    "outputs": [{
	        "internalType": "address",
	        "name": "",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "paused",
	    "outputs": [{
	        "internalType": "bool",
	        "name": "",
	        "type": "bool"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "perIntervalRewardOf",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "removeRewardSupply",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "rewardBalanceOf",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "rewardDistributorBalanceOf",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "rewardPerIntervalDivider",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "_minStakeBalance",
	        "type": "uint256"
	    }],
	    "name": "setMinStakeBalance",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "bool",
	        "name": "_paused",
	        "type": "bool"
	    }],
	    "name": "setPaused",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "_rewardPerIntervalDivider",
	        "type": "uint256"
	    }],
	    "name": "setRewardsDivider",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "_rewardInterval",
	        "type": "uint256"
	    }],
	    "name": "setRewardsInterval",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "stake",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "stakeReward",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "stakeTime",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "stakedIntervalsCountOf",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "stakingToken",
	    "outputs": [{
	        "internalType": "contract IERC20",
	        "name": "",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "totalStaked",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "totalSupply",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "unstake",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "unstakingBalanceOf",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "account",
	        "type": "address"
	    }],
	    "name": "unstakingTimeOf",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "startIndex",
	        "type": "uint256"
	    }, {
	        "internalType": "uint256",
	        "name": "endIndex",
	        "type": "uint256"
	    }],
	    "name": "updateChunkUsersRewards",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "withdrawReward",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "withdrawUnstakedBalance",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}];
	let contract2 = web3.eth.contract(abi2).at(contractaddress2);

	let contractaddress3 = "0xA615DA42030237Af51d92c1A0eF5E7bC884e94BD"; //ico contract
	let abi3 = [{
	    "inputs": [{
	        "internalType": "address",
	        "name": "TokenContract",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "constructor"
	}, {
	    "anonymous": false,
	    "inputs": [{
	        "indexed": true,
	        "internalType": "address",
	        "name": "previousOwner",
	        "type": "address"
	    }, {
	        "indexed": true,
	        "internalType": "address",
	        "name": "newOwner",
	        "type": "address"
	    }],
	    "name": "OwnershipTransferred",
	    "type": "event"
	}, {
	    "payable": true,
	    "stateMutability": "payable",
	    "type": "fallback"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "amount",
	        "type": "uint256"
	    }],
	    "name": "calculateTokenAmount",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "maxInvestment",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "maxPrice",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "minPrice",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "owner",
	    "outputs": [{
	        "internalType": "address",
	        "name": "",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "purchaseTokens",
	    "outputs": [],
	    "payable": true,
	    "stateMutability": "payable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "renounceOwnership",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "min",
	        "type": "uint256"
	    }, {
	        "internalType": "uint256",
	        "name": "max",
	        "type": "uint256"
	    }],
	    "name": "setMinMax",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "token",
	    "outputs": [{
	        "internalType": "address",
	        "name": "",
	        "type": "address"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "tokenPrice",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [],
	    "name": "totalInvestment",
	    "outputs": [{
	        "internalType": "uint256",
	        "name": "",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "address",
	        "name": "newOwner",
	        "type": "address"
	    }],
	    "name": "transferOwnership",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [{
	        "internalType": "uint256",
	        "name": "tokenPrice",
	        "type": "uint256"
	    }],
	    "name": "updatePrice",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": true,
	    "inputs": [{
	        "internalType": "address",
	        "name": "",
	        "type": "address"
	    }],
	    "name": "user",
	    "outputs": [{
	        "internalType": "bool",
	        "name": "isExist",
	        "type": "bool"
	    }, {
	        "internalType": "uint256",
	        "name": "investment",
	        "type": "uint256"
	    }],
	    "payable": false,
	    "stateMutability": "view",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "withdrawFunds",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}, {
	    "constant": false,
	    "inputs": [],
	    "name": "withdrawRemainingTokensAfterICO",
	    "outputs": [],
	    "payable": false,
	    "stateMutability": "nonpayable",
	    "type": "function"
	}];
	let contract3 = web3.eth.contract(abi3).at(contractaddress3);